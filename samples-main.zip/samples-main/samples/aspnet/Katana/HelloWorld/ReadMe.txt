HelloWorld Sample
----------------------

OWIN is a HTTP server API abstraction at enables application portability across
various servers. This sample demonstrates how to write a Hello World application
using some simple wrappers around the raw OWIN abstraction and run it on a web 
server like Asp.Net.

For more information about OWIN, please see
http://www.owin.org/
